// types.ts
export interface DataItem {
    id: string;
    date?: Date; // Adicione outros campos comuns se necessário
  }
  