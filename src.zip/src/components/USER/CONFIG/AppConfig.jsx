import React from 'react';
import { Card } from 'react-bootstrap';

const AppConfig = () => {
    return (
        <Card className="mb-4">
            <Card.Body>
                <Card.Title>Configurações do Aplicativo</Card.Title>
                <Card.Text>
                    {/* Aqui você pode adicionar as configurações do aplicativo, como:
                    - Notificações
                    - Idioma
                    - Tema
                    - Etc. */}
                    Em breve...
                </Card.Text>
            </Card.Body>
        </Card>
    );
};

export default AppConfig;
