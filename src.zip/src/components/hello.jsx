// src/components/HelloWorld.js
import React from 'react';

const Hello= () => {
    return <h1>Moto Diário</h1>;
};

export default Hello;