export const navLinks = [
    {
      href: "/",
      label: "Início",
    },
    {
      href: "/earnings",
      label: "Ganhos",
    },
    {
      href: "/abastecimentos",
      label: "Abastecimento",
    },
    {
      href: "/config",
      label: "Configs",
    },
    {
      href: "/contato",
      label: "Contato",
    },
  ];